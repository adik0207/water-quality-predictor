from flask import Flask, request, render_template
import joblib
import numpy as np
import pandas as pd

# Load model & feature columns
model = joblib.load("model/random_forest_water_quality.pkl")
features = joblib.load("model/features.pkl")

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        input_data = [float(request.form[feature]) for feature in features]
        df = pd.DataFrame([input_data], columns=features)

        # Predict
        prediction = model.predict(df)[0]
        result = "Safe to Drink" if prediction == 1 else "Not Safe to Drink"

        return render_template("index.html", prediction_text=f"Prediction: {result}")
    except Exception as e:
        return render_template("index.html", prediction_text=f"Error: {e}")

if __name__ == "__main__":
    app.run(debug=True)